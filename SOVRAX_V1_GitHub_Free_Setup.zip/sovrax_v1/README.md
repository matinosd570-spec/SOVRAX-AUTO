# SOVRAX V1 — Alert Engine

Binance USDⓈ-M USDT perpetual market scanner. This starter version is **alerts-only**:
it does not create, modify, or cancel orders and does not need Binance API keys.

## Strategy outline
- Universe: dynamically selects up to 10 active USDT-margined perpetual contracts by 24h quote volume.
- 4H: directional structure proxy from confirmed swing highs/lows.
- 1H: directional structure confirmation.
- 15M: liquidity sweep of the prior 20 completed candles.
- 5M: opposite-side market-structure shift, displacement, and FVG retest.
- Risk: illustrative 0.5% risk budget and 2R target for alert calculations only.

This is an experimental rule-based implementation, not a validated profitable strategy.
The ICT/SMC terms are operationalized as explicit approximations in `sovrax/strategy.py`.
They must be reviewed and backtested before being relied on.

## Install
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

Telegram is optional. Fill `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in `.env`.
Without them, alerts print to the terminal.

## Important safeguards
- No Binance credentials are requested or used.
- No trading orders are sent.
- Signals are evaluated on completed candles; the latest in-progress candle is excluded.
- Top-10 selection is based on reported 24h quote volume, not a guarantee of execution quality.
- Funding, spread, slippage, exchange outages, and market regime filters are not yet fully modeled.
- The risk numbers are examples. Do not treat alerts as investment advice.

## Next development milestones
1. Add persistent alert deduplication and structured logs.
2. Add historical backtest with fees, funding, slippage, and walk-forward validation.
3. Verify signal definitions against chart examples.
4. Run paper monitoring for several weeks before considering any execution module.


## Free GitHub Actions deployment (scheduled alerts)
1. Create a GitHub repository. For no-cost standard runners, use a **public** repository; this makes source code visible to everyone. Never commit tokens or keys.
2. Upload the `SOVRAX_V1_GitHub_Free_Setup.zip` file to the repository root.
3. Create `.github/workflows/scan.yml` in the repository root and copy the workflow from the `.github/workflows/scan.yml` file included in this project archive. (GitHub Actions only discovers workflow files in this exact repository path; it does not read a workflow nested inside the uploaded ZIP.)
4. Add repository secrets named `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`.
5. Open Actions and run `SOVRAX signal scan` manually once. Then the schedule runs every 15 minutes (subject to GitHub scheduling delays).

The scheduled workflow unpacks the ZIP and runs one scan per execution. GitHub's minimum schedule interval is 5 minutes; this project uses 15 minutes to reduce unnecessary API calls. Scheduled workflows can be delayed. This is not a real-time trading service.
