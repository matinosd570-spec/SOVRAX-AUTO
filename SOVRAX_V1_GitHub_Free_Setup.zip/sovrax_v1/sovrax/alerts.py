import requests

class AlertManager:
    def __init__(self, token="", chat_id=""):
        self.token = token.strip()
        self.chat_id = chat_id.strip()
        self.sent = set()

    def send(self, signal):
        key = (signal.symbol, signal.side, signal.candle_time)
        if key in self.sent:
            return
        self.sent.add(key)
        text = (
            f"👑 SOVRAX V1 SIGNAL — {signal.side.upper()}\n"
            f"Symbol: {signal.symbol}\n"
            f"Entry reference: {signal.entry:.8g}\n"
            f"Stop: {signal.stop:.8g}\n"
            f"Target (illustrative {2.0:.1f}R): {signal.target:.8g}\n"
            f"Risk budget: {signal.risk_pct:.2f}% (not an order)\n"
            f"Reason: {signal.reason}\n"
            "Status: ALERT ONLY — no order was placed."
        )
        print("\n" + text + "\n")
        if self.token and self.chat_id:
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            try:
                requests.post(url, json={"chat_id": self.chat_id, "text": text}, timeout=10).raise_for_status()
            except requests.RequestException as exc:
                print(f"[WARN] Telegram alert failed: {exc}")
