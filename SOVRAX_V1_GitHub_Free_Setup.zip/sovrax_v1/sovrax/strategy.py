from dataclasses import dataclass
import pandas as pd

@dataclass
class Signal:
    symbol: str
    side: str
    entry: float
    stop: float
    target: float
    risk_pct: float
    reason: str
    candle_time: int

def swing_points(df, left=2, right=2):
    highs, lows = [], []
    for i in range(left, len(df) - right):
        window = df.iloc[i-left:i+right+1]
        if float(df.high.iloc[i]) == float(window.high.max()):
            highs.append((i, float(df.high.iloc[i])))
        if float(df.low.iloc[i]) == float(window.low.min()):
            lows.append((i, float(df.low.iloc[i])))
    return highs, lows

def structure_bias(df):
    highs, lows = swing_points(df)
    if len(highs) < 2 or len(lows) < 2:
        return "neutral"
    hh = highs[-1][1] > highs[-2][1]
    hl = lows[-1][1] > lows[-2][1]
    lh = highs[-1][1] < highs[-2][1]
    ll = lows[-1][1] < lows[-2][1]
    if hh and hl:
        return "bullish"
    if lh and ll:
        return "bearish"
    return "neutral"

def find_signal(symbol, d4h, d1h, d15, d5, risk_pct=0.5, rr=2.0):
    if min(map(len, [d4h, d1h, d15, d5])) < 40:
        return None

    bias4h = structure_bias(d4h)
    bias1h = structure_bias(d1h)
    if bias4h not in ("bullish", "bearish") or bias1h != bias4h:
        return None

    prior15 = d15.iloc[-21:-1]
    last15 = d15.iloc[-1]
    if bias4h == "bullish":
        swept = float(last15.low) < float(prior15.low.min()) and float(last15.close) > float(prior15.low.min())
        side = "long" if swept else None
    else:
        swept = float(last15.high) > float(prior15.high.max()) and float(last15.close) < float(prior15.high.max())
        side = "short" if swept else None
    if not side:
        return None

    # Find a recent displacement/MSS candle that created an FVG,
    # then require a later completed candle to retest that gap.
    highs, lows = swing_points(d5)
    recent = d5.iloc[-8:].reset_index(drop=True)
    last = recent.iloc[-1]
    median_range = float((recent.high - recent.low).median())
    if median_range <= 0:
        return None

    if side == "long":
        candidates = []
        for i in range(2, len(recent)-1):
            prior_highs = [p for p in highs if p[0] < len(d5)-8+i]
            if not prior_highs:
                continue
            mss_level = prior_highs[-1][1]
            candle = recent.iloc[i]
            body = abs(float(candle.close) - float(candle.open))
            bullish_fvg = float(candle.low) > float(recent.high.iloc[i-2])
            mss = float(candle.close) > mss_level
            displacement = float(candle.close) > float(candle.open) and body >= 1.2 * median_range
            if bullish_fvg and mss and displacement:
                zone_low = float(recent.high.iloc[i-2])
                zone_high = float(candle.low)
                candidates.append((i, zone_low, zone_high))
        if not candidates:
            return None
        i, zone_low, zone_high = candidates[-1]
        retest = float(last.low) <= zone_high and float(last.high) >= zone_low and float(last.close) >= zone_low
        if not retest:
            return None
        entry = (zone_low + zone_high) / 2
        sweep_low = float(last15.low)
        stop = min(sweep_low, float(last.low))
        if stop >= entry:
            return None
        target = entry + rr * (entry - stop)
        reason = "4H/1H bullish structure; 15M sell-side sweep; 5M bullish MSS, displacement, FVG creation and later retest"
    else:
        candidates = []
        for i in range(2, len(recent)-1):
            prior_lows = [p for p in lows if p[0] < len(d5)-8+i]
            if not prior_lows:
                continue
            mss_level = prior_lows[-1][1]
            candle = recent.iloc[i]
            body = abs(float(candle.close) - float(candle.open))
            bearish_fvg = float(candle.high) < float(recent.low.iloc[i-2])
            mss = float(candle.close) < mss_level
            displacement = float(candle.close) < float(candle.open) and body >= 1.2 * median_range
            if bearish_fvg and mss and displacement:
                zone_low = float(candle.high)
                zone_high = float(recent.low.iloc[i-2])
                candidates.append((i, zone_low, zone_high))
        if not candidates:
            return None
        i, zone_low, zone_high = candidates[-1]
        retest = float(last.high) >= zone_low and float(last.low) <= zone_high and float(last.close) <= zone_high
        if not retest:
            return None
        entry = (zone_low + zone_high) / 2
        sweep_high = float(last15.high)
        stop = max(sweep_high, float(last.high))
        if stop <= entry:
            return None
        target = entry - rr * (stop - entry)
        reason = "4H/1H bearish structure; 15M buy-side sweep; 5M bearish MSS, displacement, FVG creation and later retest"

    return Signal(
        symbol=symbol, side=side, entry=entry, stop=stop, target=target,
        risk_pct=risk_pct, reason=reason,
        candle_time=int(d5.timestamp.iloc[-1])
    )
