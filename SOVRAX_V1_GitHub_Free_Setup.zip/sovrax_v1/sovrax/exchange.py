import ccxt
import pandas as pd

TIMEFRAMES = {"4h": "4h", "1h": "1h", "15m": "15m", "5m": "5m"}

class BinanceFeed:
    def __init__(self):
        self.exchange = ccxt.binanceusdm({
            "enableRateLimit": True,
            "options": {"defaultType": "future"},
        })
        self.markets = None

    def load_markets(self):
        if self.markets is None:
            self.markets = self.exchange.load_markets()
        return self.markets

    def top_usdt_perpetuals(self, limit=10):
        markets = self.load_markets()
        tickers = self.exchange.fetch_tickers()
        candidates = []
        for symbol, market in markets.items():
            if not market.get("active"):
                continue
            if not market.get("swap") or market.get("quote") != "USDT":
                continue
            if market.get("settle") != "USDT":
                continue
            ticker = tickers.get(symbol) or {}
            quote_volume = ticker.get("quoteVolume")
            if quote_volume is None:
                base_volume, last = ticker.get("baseVolume"), ticker.get("last")
                if base_volume is not None and last is not None:
                    quote_volume = float(base_volume) * float(last)
            if quote_volume is None:
                continue
            candidates.append((symbol, float(quote_volume)))
        candidates.sort(key=lambda item: item[1], reverse=True)
        return [symbol for symbol, _ in candidates[:limit]]

    def candles(self, symbol, timeframe, limit=220):
        rows = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        df = pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"])
        if len(df) > 1:
            # Exclude the currently forming candle.
            df = df.iloc[:-1].copy()
        return df.reset_index(drop=True)
