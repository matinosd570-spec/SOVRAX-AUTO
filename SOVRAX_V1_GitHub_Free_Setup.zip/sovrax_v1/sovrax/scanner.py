from .strategy import find_signal

class Scanner:
    def __init__(self, feed, alerts):
        self.feed = feed
        self.alerts = alerts

    def run_once(self):
        symbols = self.feed.top_usdt_perpetuals(limit=10)
        print(f"[SCAN] monitoring {len(symbols)} USDT perpetual symbols: {', '.join(symbols)}")
        for symbol in symbols:
            try:
                d4h = self.feed.candles(symbol, "4h")
                d1h = self.feed.candles(symbol, "1h")
                d15 = self.feed.candles(symbol, "15m")
                d5 = self.feed.candles(symbol, "5m")
                signal = find_signal(symbol, d4h, d1h, d15, d5)
                if signal:
                    self.alerts.send(signal)
            except Exception as exc:
                print(f"[WARN] {symbol}: {exc}")
