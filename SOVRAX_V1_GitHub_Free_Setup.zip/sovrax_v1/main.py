import argparse
import os
import time
from dotenv import load_dotenv
from sovrax.exchange import BinanceFeed
from sovrax.scanner import Scanner
from sovrax.alerts import AlertManager

load_dotenv()

def run_once():
    feed = BinanceFeed()
    alerts = AlertManager(
        token=os.getenv("TELEGRAM_BOT_TOKEN", ""),
        chat_id=os.getenv("TELEGRAM_CHAT_ID", ""),
    )
    Scanner(feed, alerts).run_once()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="Run one scan and exit")
    args = parser.parse_args()

    if args.once:
        run_once()
        return

    interval = int(os.getenv("SCAN_INTERVAL_SECONDS", "60"))
    print("SOVRAX V1 Alert Engine started — alerts only; no order execution.")
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            print("Stopping SOVRAX.")
            break
        except Exception as exc:
            print(f"[ERROR] scan cycle failed: {exc}")
        time.sleep(interval)

if __name__ == "__main__":
    main()
